﻿using System.Windows;

namespace $rootnamespace$
{
    /// <summary>
    /// Interaction logic for $safeitemname$.xaml
    /// </summary>
    public partial class $safeitemname$ : Window
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
