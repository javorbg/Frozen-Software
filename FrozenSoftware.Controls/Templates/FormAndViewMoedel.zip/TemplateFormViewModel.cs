﻿using FrozenSoftware.Controls;
using FrozenSoftware.Models;
using Prism.Regions;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Unity;

namespace $rootnamespace$
{
    public class $safeitemname$ViewModel : BaseFormViewModel
    {
        public Object Entity { get; set; }
		

        public override void Initialize(int? entityId, ActionType actionType, List<object> additionalData = null)
        {
            base.Initialize(entityId, actionType, additionalData);

            switch (actionType)
            {
                case ActionType.Add:
                    // int lastId = 1;

                    // if (DummyDataContext.Context.Entity.Count > 0)
                        // lastId = DummyDataContext.Context.Entity.Select(x => x.Id).Max() + 1;

                    // Entity = new Entity() { Id = lastId };
                    break;
                case ActionType.Edit:
                    // Entity = DummyDataContext.Context.Entity.First(x => x.Id == entityId.Value);
                    break;
            }
        }

        protected override void OnConfirmCommand()
        {
            if (ActionType == ActionType.Add)
            {
                // DummyDataContext.Context.Entity.Add(Entity);
            }

            DialogResult = true;

            if (Close != null)
                Close.Invoke();
        }
    }
}
