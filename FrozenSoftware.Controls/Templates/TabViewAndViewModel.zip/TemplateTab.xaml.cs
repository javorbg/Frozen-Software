﻿using System.Windows.Controls;

namespace $rootnamespace$
{
    /// <summary>
    /// Interaction logic for $safeitemname$.xaml
    /// </summary>
    public partial class $safeitemname$ : TabItem
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
