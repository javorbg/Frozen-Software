﻿using FrozenSoftware.Controls;
using FrozenSoftware.Models;
using Prism.Regions;
using System.Collections.ObjectModel;
using Unity;

namespace $rootnamespace$
{
    public class $safeitemname$ : BaseTabViewModel
    {
        public $safeitemname$(IRegionManager regionManger, IUnityContainer unityContainer) : base(regionManger, unityContainer)
        {
        }

        public ObservableCollection<object> Objects { get; set; }
    }
}
